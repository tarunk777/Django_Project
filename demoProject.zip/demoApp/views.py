from django.shortcuts import render, HttpResponse, redirect
from demoApp.forms import UploadFileForm
# Create your views here.
def home(request):
    if request.method == 'POST':
        form = UploadFileForm(request.POST,request.FILES)
        if form.is_valid():
            form.save()
            return HttpResponse('success')
        return HttpResponse('unsuccess')
    form = UploadFileForm() 
    return render(request,'login.html',{'form':form})