from django import forms
from demoApp.models import Product
class UploadFileForm(forms.ModelForm):
    class Meta:
        model = Product
        fields = ('__all__')