from django.contrib import admin
from demoApp.models import Product
# Register your models here.

admin.site.register(Product)
